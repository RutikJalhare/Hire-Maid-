<?php
if (isset($_POST['upload']))
{ 
if(isset($_FILES['filer']['name'])) 
{
  $image_name=$_FILES['filer']['name'];

//upload image only when image is selected
  $source_path=$_FILES['filer']['tmp_name'];
  $destination_path="./mimages/".$image_name;
         $upload=move_uploaded_file($source_path,$destination_path) ;

if($upload==true) 
{
//$image_name="$image_name";
//$image_name="not upload";
echo "ok";
}
else
{
//$image_name="$image_name";
//$image_name="not upload";
echo "not upload";
}
}

else{

echo "not Added";

}

}
?>

 
 
<!DOCTYPE html>

<html> 

   

<head> 

    <title>Image Upload</title> 

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"> 

    <link rel="stylesheet" type="text/css" href="style.css" /> 

</head> 

   

<body> 

    <div id="content"> 

        <form method="POST" enctype="multipart/form-data" > 

            <div class="form-group"> 

                <input class="form-control" type="file" name="filer" value="" required/> 

            </div> 

            <div class="form-group"> 

                <button class="btn btn-primary" type="submit" name="upload">UPLOAD</button> 

            </div> 

        </form> 

    </div> 

    <div id="display-image"> 

    
    </div> 

</body> 

 

</html>





