<?php
/*include 'database_conn.php';


$userid=$_GET['id'];

$sql="SELECT * FROM manage_order WHERE id='$userid'";


//$sql="SELECT * FROM  owener ";
$res=mysqli_query($conn,$sql) ;


$count=mysqli_num_rows($res) ;


if($count>0)
{

while($rows=mysqli_fetch_assoc($res))
{

echo $name=$rows['name'];
echo $requirment=$rows['requirments'];
echo $address=$rows['address'];
echo $status=$rows['status'];
echo $shop_name=$rows['shop_name'];
echo $shop_address=$rows['shop_address'];
echo $owenercontact=$rows['owenercontact'];
echo $contact=$rows['contact'];

?>



<?php

}

}

*/
?>



<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">


<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<style>

#id{

position:relative;
left:-10px;
}

.head-of-profile{
background-color:#2c3e50;

}


#update{
animation-name: example;
  animation-duration: 3s;
animation-iteration-count:1;





}



@keyframes example {
  from {height:20px;color:#2c3e50;}
  to {height:600px;color:white;}
}

 



</style>




<body>

<!-------  start of  order div from here -->
<div  id="od" class=" p-4 order-div">

 

<div class="container">

 <p class="lead ">Your  Order</p> 

<div class="container">



<div class="row">

<?php
include 'database_conn.php';


$userid=$_GET['id'];

$sql="SELECT * FROM manage_order WHERE id='$userid'";


//$sql="SELECT * FROM  owener ";
$res=mysqli_query($conn,$sql) ;


$count=mysqli_num_rows($res) ;


if($count>0)
{

while($rows=mysqli_fetch_assoc($res))
{

$name=$rows['name'];
$requirment=$rows['requirements'];
$address=$rows['address'];
$status=$rows['status'];
$shop_name=$rows['shop_name'];
$shop_address=$rows['shop_address'];
$owenercontact=$rows['owenercontact'];
$contact=$rows['contact'];

?>


<div class="text-center mt-3 col-md-6">
<div class="order-info">



<div class="card"> 

<img  height="170px" class="card-img rounded-circle" src="
Images/business-woman-standing-cartoon-employee-vector-15325133.jpg" alt="Card image cap"> 

<div class="card-body"> 

<a href="service_provide_profile_for_user.php"class="btn btn-primary pill" >
<?php echo $shop_name;;?>

</a>
<p class="mt-3 fw-bold card-text lead">Order </br>
<span class="fw-bold text-secondary" ><?php echo $requirment;?></span>
</p> 


<address class="lead" >
<?php echo $shop_address;?>
</address>


<input  type="submit"  value="Cancel Order" class="btn btn-block btn-danger">


<p class="fw-bold text-secondary">status
<span class=" text-danger" >
<?php
if($status==1) 
{
echo "Accepted";
}
if($status==2) 
{
echo "Progress";
}
if($status==3) 
{
echo "Delivered";
}

if($status==4) 
{
echo "Rejected";
}

?>





</span></p>

</div> 

</div>


</div>
</div>

<?php

}

}


?>



<!--- -->










<!--- end of order  div here -->




</body>
</html>
