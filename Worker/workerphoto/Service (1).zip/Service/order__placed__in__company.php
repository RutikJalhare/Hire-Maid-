<?php
ob_start();
include 'database_conn.php';
session_start(); 
$owenerid=$_SESSION["id"];

//updating status
if(isset($_GET['shopname'])  && (isset($_GET['status']) && isset($_GET['userid'])
&& isset($_GET['req'])
)) 
{
$status=$_GET['status'];
$shopname=$_GET['shopname'];
$userid=$_GET['userid'];
$req=$_GET['req'];

}

$shopname=$_GET['shopname'];
$status=$_GET['status'];



$userid=$_GET['userid'];
$req=$_GET['req'];
$sql2="UPDATE manage_order SET 
status='$status'
WHERE shop_name='$shopname' && id='$userid' &&
requirements='$req'
";
$res=mysqli_query($conn,$sql2)or die(mysqli_error());


?>
<!--verification div start -->
<div style="display:none" id="own" >
    
<div class="modal-dialog">
   <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>Some text in the modal.</p>
        </div>
        <div class="modal-footer">

<button onclick="cd()" type="button" class="btn btn-info btn-lg" >close</button>

          
        </div>
      </div>
      
    </div>
  </div>
  
</div>



<!--verfication div end -->

<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">


<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<style>

#id{

position:relative;
left:-10px;
}

.head-of-profile{
background-color:#2c3e50;

}


#update{
animation-name: example;
  animation-duration: 3s;
animation-iteration-count:1;





}



@keyframes example {
  from {height:20px;color:#2c3e50;}
  to {height:600px;color:white;}
}

 



</style>




<body>
<?php


$sql="SELECT * FROM owener WHERE id=$owenerid";
//$sql="SELECT * FROM  owener ";
$res=mysqli_query($conn,$sql) ;
$count=mysqli_num_rows($res) ;
if($count>0)
{
while($rows=mysqli_fetch_assoc($res))
{
 $shopname=$rows['shop_name'];
//echo $owenerid=$rows['id'];
}
}
?>



<!-------  start of  order div from here -->
<div  id="od" class=" p-4 order-div">

 

<div class="container">

 <p class="lead ">Manage Order</p> 

<div class="container">


<div class="row">
<?php
$sql="SELECT * FROM manage_order WHERE shop_name='$shopname'";


//$sql="SELECT * FROM  owener ";
$res=mysqli_query($conn,$sql) ;


$count=mysqli_num_rows($res) ;


if($count>0)
{

while($rows=mysqli_fetch_assoc($res))
{
$userid=$rows['id'];
$name=$rows['name'];
$cust_image=$rows['cust_image'];
$requirment=$rows['requirements'];
$address=$rows['address'];
$status=$rows['status'];
$shop_name=$rows['shop_name'];
$shop_address=$rows['shop_address'];
$owenercontact=$rows['owenercontact'];
$contact=$rows['contact'];

?>



<div class="text-center mt-2 col-md-6">
<div class="order-info">
<div class="card"> 
<!--<img  height="170px" class="card-img rounded-circle" src="
Images/business-woman-standing-cartoon-employee-vector-15325133.jpg" alt="Card image cap">
<?php echo SITEURL;?>mimages/<?php echo $userphoto;?>-->
<img  height="170px" class="card-img rounded-circle" src="
<?php echo SITEURL;?>mimages/<?php echo $cust_image;?>">
 
<div class="card-body"> 
<span class="btn btn-primary pill" >
<?php echo $name;?></span>
<p class="card-text fw-bold">
<?php echo $requirment;?></p> 
<address class="lead">
<?php echo $address;?>
</address>
<p>Mob :<span><?php echo $contact;?></span></p>


<input  type="submit"  value="Accept order" class="btn btn-block btn-danger">

<p class="fw-bold">status
<span class="text-danger">
<?php
if($status==1) 
{
echo "Accepted";
}
if($status==2) 
{
echo "Progress";
}
if($status==3) 
{
echo "Delivered";
}

if($status==4) 
{
echo"Rejected";
}

?>


</span>

</p>

<select onchange="status_update(this.options[this.selectedIndex].value,'<?php echo $shopname?>',
'<?php echo $userid ?>','<?php echo $requirment ?>'




)" class="form-select" aria-label="Default select example">
  <option selected>Update status</option>
  <option value="1">Accepted </option>
  <option value="2">Progress</option>
  <option value="3">Delivered</option>
  <option value="4">Rejected</option>

</select>


<script>
function status_update(status,shopname,userid,requirment)
{

//alert(status+"    "+shopname+"    "+userid+"    "+requirment);

window.location.href = "http://0.0.0.0:8080/Main_project/Service/order__placed__in__company.php?status="+status+"&shopname="+shopname+"&userid="+userid+"&req="+requirment;


//window.location.href = "http://0.0.0.0:8080/dynamic_stautus_update.php/status_update.php?status="+status;

}

/*window.location.href="http://0.0.0.0:8080/Main_project/Service/order__placed__in__company.php?shopname="+shopname;*/

</script>











</div> 
</div>
</div>
</div>


<?php


}
}
?>





</div>
</div>

<!--- end of order  div here -->










</body>
</html>
