<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">


<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<style>
.user-main{
background-color:#2c3e50;
}
#id{

position:relative;
left:-10px;
}

.head-of-profile{
background-color:#2c3e50;

}


#update{
animation-name: example;
  animation-duration: 3s;
animation-iteration-count:1;





}



@keyframes example {
  from {height:20px;color:#2c3e50;}
  to {height:600px;color:white;}
}

 



</style>




<body>
 
<div class="container"> 
<div class="row"> 

<div class="col-md-2">

<div class="logo">
<img src="/storage/emulated/0/htdocs/Laundry_project/depositphotos_268012950-stock-illustration-laundry-service-vector-emblem-in.jpg">
</img>
</div>


</div>
<!--   -->
<div class="col-md-10  text-end">

<div class="logo ">

<a href="#">
<i  class="mt-3 fa-solid fa-envelope fa-3x"></i></a><span  if="noti" class="me-4 badge bg-danger">4</span>

<a href="#"><i class="mt-3 fa-3x fa-solid fa-user"></i>
</a>
<span class=" fw-bold text-muted lead">My profile</span>

</div>

</div>

</div>
</div>


<!-- -->
<div class="serv-provide-place-order">
<div class="container">
<div class="row">

<div class="col-md-4">
<div class="mt-5  serv-info">
<h4>Shop name</h4>
<pclass=" lead ">Rutik jalhare
</br>
Mob :+91 957 973 5564</p>
 
<address>
Written by 
Visit us at:<br>
Example.com<br>
Box 564, Disneyland<br>
USA
</address>


<button type="button" class="btn btn-dark btn-lg btn-block">Shop certificate</button>

</div>
</div>



<div class=" p-5 col-md-8">
<div class="sele">





<p class="lead fw-bold">Select here </p>
<select class="form-select" multiple aria-label="multiple select example"> 
  <optgroup label="Men's">
    <option value="1">Shirt</option>
    <option value="2">T-shirt</option>
    <option value="3">Suit</option>
  <option value="4">Jacket </option>
    <option value="5">Payjama</option>
    <option value="6">Lether jacket</option>

<option value="7">Sandos</option>


  </optgroup>
  <optgroup label="Women's">
    <option value="1">Shirt</option>
    <option value="2">Jeans</option>
    <option value="3">Saree</option>
 

  </optgroup>
</select>





</div>

</div>






</div>
</div>
</div>






<!-- -->

<div class="user-main">
<div class="container">




<!--  first row end here that us search -->
<div class="row">
<div class="col-md-6">

<div class=" card ">

<div class="card-body"> 
<h4 class="card-title">Shop name</h4>
<pclass=" lead ">Rutik jalhare
</br>
Mob :+91 957 973 5564</p>
 
<address>
Written by 
Visit us at:<br>
Example.com<br>
Box 564, Disneyland<br>
USA
</address>


<button type="button" class="btn btn-dark btn-lg btn-block">View me </button>


</div>
</div>

</div>
<!---   -->
<div class="col-md-6">

<div class=" card ">

<div class="card-body"> 
<h4 class="card-title">Shop name</h4>
<pclass=" lead ">Rutik jalhare
</br>
Mob :+91 957 973 5564</p>
 
<address>
Written by 
Visit us at:<br>
Example.com<br>
Box 564, Disneyland<br>
USA
</address>


<button type="button" class="btn btn-dark btn-lg btn-block">View me </button>


</div>
</div>

</div>



<!--  -->





</div>
<!--  second row end here that us search -->







</div>
</div>
</div>







</body>
</html>
