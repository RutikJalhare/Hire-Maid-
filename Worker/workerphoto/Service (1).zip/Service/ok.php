<?php
include 'database_conn.php';

$owener=$_GET['oweid'];
$userid=$_GET['userid'];


if(empty($_POST['requirment'])) 
{
 $reqErr = "Please enter Your requiements";
}
else
{
$req=$_POST["requirment"];
}


$sql="SELECT * FROM owener WHERE id=$owener";


//$sql="SELECT * FROM  owener ";
$res=mysqli_query($conn,$sql) ;


$count=mysqli_num_rows($res) ;


if($count>0)
{

while($rows=mysqli_fetch_assoc($res))
{

$shop_name=$rows['shop_name'];
 $main_ser=$rows['main_ser'];$sub_ser=$rows['sub_ser'];
$city=$rows['city'];
$shop_address=$rows['address'];
$email=$rows['email'];
$shop_contact=$rows['contact'];
$shop_lic=$rows['shop_lic'];



?>

<!Doctype html> 
<html lang="en"> 


<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

  

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 

<section style="background-color: #eee;">
  <div class="container py-5">


<!--<a class="btn btn-primary"  href="http://0.0.0.0:8080/Main_project/Service/ok.php?oweid=<?php echo $owener ?>& userid=<?php echo $userid;?>" >Read More </a>

-->

    <div class="row">


      <div class="col">
        <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4">
          
        </nav>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
            <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp" alt="avatar"
              class="rounded-circle img-fluid" style="width: 150px;">
            <h5 class="my-3"><?php echo $shop_name?></h5>
            


<p class="fw-bold text-danger mb-1"><?php echo $main_ser?></p>
<p class="fw-bold text-dark mb-1"><?php echo $sub_ser?></p>

            <p class="text-muted mb-4"><?php echo $address."  ".$city?></p>

            <div class="d-flex justify-content-center mb-2">
<form method="POST">
  <textarea name="requirment" placeholder="Enter Requirement Here " class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea> 
<span  class="lead error text-danger">*<?php echo $reqErr;?></span>

            </div>

 <input name="book" type="submit" value="Book"   class="btn btn-primary">




</form>
          </div>
        </div>


<!--  placing success error model her -->



<!--   -->






<?php

//echo $shop_name;
//getting user data 
$sql="SELECT * FROM user WHERE id=$userid";


//$sql="SELECT * FROM  owener ";
$res=mysqli_query($conn,$sql) ;


$count=mysqli_num_rows($res) ;


if($count>0)
{

while($rows=mysqli_fetch_assoc($res))
{
$req;
$shop_name;
$name=$rows['name'];
$photo=$rows['photo'];
$address=$rows['address'];

$contact=$rows['contact'];
}
}


//getting user data end here 

}
}

if(isset($_POST['book'])) 
{

/*echo "required".$req;
echo "shopname___".$shop_name;
echo "username".$name;
echo "useraddress".$address;
echo "useracontact".$contact;
*/
if(empty($reqErr)) 
{
//checking data  all data is valid or not 


/*echo "userid".$userid;
echo "username".$name;
echo "required".$req;
echo "useraddress".$address;

echo "useracontact".$contact;
echo "shopname___".$shop_name;
echo "address".$shop_address;

echo "contact".$shop_contact;
*/

//inseting data into table manage order 
$sql3="INSERT INTO manage_order SET
id='$userid',
name='$name',
cust_image='$photo', 
requirements='$req',
address='$address',
status=' ', 
shop_name='$shop_name', 
shop_address='$shop_address', 
owenercontact='$shop_contact', 
contact='$contact'
";

$res3=mysqli_query($conn,$sql3)or die(mysqli_error($conn)) ;
if($res3==true)
{
?>

<h2 class="lead  fw-bold text-sucess">
<?php echo "order placed Successfully";?>
</h2>
<?php




}
else
{
echo "not inserted";
}


//insettit end here 


}

else
{
//echo "please mention service ";
}


}







?>
</body>
</html>

