<?php
ob_start();
include 'database_conn.php';
$id=$_GET['id'];

$sql="SELECT * FROM  user WHERE id =$id";
$res=mysqli_query($conn,$sql) ;


$count=mysqli_num_rows($res) ;


if($count>0)
{

while($rows=mysqli_fetch_assoc($res))
{
 $name=$rows['name'];
 $address=$rows['address'];
 $userphoto=$rows['photo'];
 $contact=$rows['contact'];
 $email=$rows['email'];
}
}
?>
<!--update user profile php -->
<?php
if(isset($_POST['savec'])) 
{
//echo "ok";
$emailErr="";
$contactErr="";
$addressErr="";



if(empty($_POST['email'])) 
{
$emailErr = "This field is required";
}
else
{
$email = test_input($_POST['email']);
}


if(empty($_POST['phone'])) 
{
$contactErr = "This field is required";
}
else
{
 $contact = test_input($_POST['phone']);
$contactErr=validating($contact);

}



if(empty($_POST['address'])) 
{
$addressErr = "Mention Address please ";
}
{
  $address=Address($_POST['address']);
}

//uploading file
$image_name=$_FILES['use']['name'];
$source_path=$_FILES['use']['tmp_name'];
  $destination_path="./mimages/".$image_name;


if(empty($addressErr)  && empty($contactErr)  &&
empty($emailErr)   
)
{
//if all data is valid them upload file and update the data ";
$upload=move_uploaded_file($source_path,$destination_path) ;
if($upload) 
{
//echo "all data us correct &file uploaded ";
//now update data 
$sql3="UPDATE user SET
address='$address',
photo='$image_name',
contact='$contact', 
email='$email'
WHERE id=$id;
";


$res3=mysqli_query($conn,$sql3)or die(mysqli_error($conn)) ;
if($res3==true) 
{
//echo " update successful";
//header('location:'.SITEURL.'admin/product.php') ;

}
else
{
//echo "not update ";
?>

<h2 class="lead  fw-bold
text-danger">
<?php echo "Updation failed !Technical  Error ";?>
</h2>
<?php

}








}
else
{
?>

<h2 class="lead  fw-bold
text-danger">
<?php echo "Updation failed !Technical  Error ";?>
</h2>
<?php
}





}


//if all data is not emter properlly
else
{
?>

<h2 class="lead  fw-bold
text-danger">
<?php echo "Updation failed ! Please make sure that enter data is valid. ";?>
</h2>
<?php
}


 /*      $upload=move_uploaded_file($source_path,$destination_path) ;

if($upload==true) 
{
//
//echo "upload ";
}
else
{

$userphotoErr="Not Upload";
}


if(empty($addressErr)  && empty($contactErr)  &&
empty($emailErr)    &&
empty($userphotoErr)
)
{
echo "updated";
}
else
{
echo "Updation failed ! Please make sure that enter data is valid. ";
}


*/




//end of main if 

}

function validating($phone){ if(preg_match('/^[0-9]{10}+$/', $phone)) 
{

}
else
{
$invalid="invalid contact";
return $invalid;
}
} 





function test_input($data) 
{
$data = trim($data);
$data = stripslashes($data);
$data = htmlspecialchars($data);
return $data;
}

function RemoveSpecialChar($str) 
{
$res = str_replace( array('1','2','3',   
'4', '5', '6', '7', '8', '9', '0', 


',','.','!','? ',"'",'"', ':','*','/', '&','-','+','(','#','₹','_' ,'@','\'', '"',
	',' , ')' ,';', '<', '>' ), ' ','=',$str);
	return $res;
}

function Address($str) 
{
$res = str_replace( array(
',','.','!','? ',"'",'"', ':','*','/', '&','-','+','(','#','₹','_' ,'@','\'', '"',
	',' , ')' ,';', '<', '>' ), ' ', $str);
	return $res;
}




?>




<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">


<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<style>
#id{

position:relative;
left:-10px;
}

.head-of-profile{
background-color:#2c3e50;

}


#update{
animation-name: example;
  animation-duration: 3s;
animation-iteration-count:1;





}



@keyframes example {
  from {height:20px;color:#2c3e50;}
  to {height:600px;color:white;}
}

 



</style>




<body>
 
<div class="container"> 
<div class="row"> 

<div class="col-md-2">

<div class="logo">
<img src="Images/logo.png">




</div>


</div>
<!--   -->
<div class="col-md-10   text-end">

<div class="logo ">

</div>

</div>

</div>
</div>

<!--   -->

<!--


<div class="head-of-profile">
<div class="container">
<div class="row">





<div class="col-md-6">


<div class=" card ">
<img class="card-img" src="/storage/emulated/0/htdocs/Laundry_project/business-woman-standing-cartoon-employee-vector-15325133.jpg"  width="20px;"  height="200px;" alt="Card image cap"> 

<div class="card-body"> 
<h5 class="card-title">John Doe</h5> 
<address>
Written by 
Visit us at:<br>
Example.com<br>
Box 564, Disneyland<br>
USA
</address>
<h4 class="fw-bold text-danger">Service</h4>
<p class=" lead">
Laundry. </br>
Dry cleaning. </br>
Steam ironing. </br>

</p>

 <a href="#" class="btn btn-primary">Go somewhere</a> 
</div>
</div>
</div>

</div>



</div>
</div>
</div>

-->
<div class="head-of-profile">
<div class="container">
<div class="row">

<!--<img  src="<?php echo SITEURL;?>images/img/<?php echo $image_name;?>"
-->

<div class=" col-md-4">
<div class=" card ">
<img class="card-img" src="<?php echo SITEURL;?>mimages/<?php echo $userphoto;?>"

width="20px;"  height="200px;" alt="Card image cap"> 

<div class="card-body"> 

<p class="fw-bold lead "><?php echo $name ;?> </br>
<p class=" lead ">Mob :<?php echo $contact ;?> </p>
<p class=" lead ">Email  :  <?php echo $email ;?> </p>
<address class="lead">
<?php echo $address ;?> 
</address>


<!--<a  href="" onclick="showupdate()" type="button" class="btn btn-dark btn-lg btn-block">Edit</a>-->


<button onclick="showupdate()" type="button" class="btn btn-dark btn-lg btn-block">Edit</button>


<!--<button onclick="showupdate()" type="button" class="btn btn-dark btn-lg btn-block">Edit</button> -->
</div>
</div>

</div>
<!--- -->
<div class="col-md-8">
<div  style="display:none" id="update" class="card bg-dark text-white" style="border-radius: 1rem;">

          <div class="card-body p-5 text-center">


<!--<i class="  fa-solid fa-rectangle-xmark"></i>
-->

<i onclick="hideupdate()" style="position:relative;top:-30px;left:200px;" class="fa-solid fa-xmark"></i>


<h2 class="fw-bold lead"><?php echo $name ;?></h2>


<form method="POST" enctype="multipart/form-data" > 

  <!-- Name input -->
 
 


  <!-- Email input -->
  <div class="form-outline mb-4">
    <input type="email" placeholder="Email " class="form-control" 
name="email"/>
</br>
<span class="lead error text-danger">*<?php echo $emailErr;?></span>         


  </div>

  <div class="form-outline mb-4">
    <input type="text"  placeholder="phone " name="phone" class="form-control" />
   </br>
<span class="lead error text-danger">*<?php echo $contactErr;?></span>    
  </div>






  <!-- Message input -->
  <div class="form-outline mb-4">
    <textarea class="form-control"   placeholder="Enter Address Here " name="address" rows="4"></textarea>
</br>
<span class="lead error text-danger">*<?php echo $addressErr;?></span>    
 
  </div>

  <div class="col-md-6 mb-4 pb-2">
    <input class="form-control" type="file" accept="image/*" name="use" required>
    <label for="basic-url">Upload Photo</label>          
</div>


  <!-- Submit button -->

<input type="submit" name="savec"class="btn btn-primary btn-lg btn-block" value="Save changes">


 
</form>

        

           </div>
           </div>
           </div>

<!--  search div start from here-->




<!--  search div end here-->


</div>
</div>
</div>




<script>
function showupdate() {


document.getElementById("update").style.display = "block";


}

function hideupdate() {
document.getElementById("update").style.display = "none";


}


</script>




</body>
</html>
