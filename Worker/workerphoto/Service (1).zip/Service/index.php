<!Doctype html> 
<html lang="en"> 
<head>  
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
 

<link  href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>



</head> 

<body>
<div class="top-space2">




<div class="top-sec">
<div class="container">
<div class="row">
<div class="col-md-2">
<div class="logo">

<img src="Images/logo.png">






</div>
</div>


<div class="col-md-10">
<div class="links">
<ul  id="menu" class="float-end">
<li><a href="#div1">Home</a></li>
<li><a href="#div3">About us</a></li>
<li><a  href="#div3">Contact us</a></li>

</ul>
</div>
</div>
</div>
</div>





<!--    -->

<div class="row">
<div id="div1" class="top-seco">
<div class="col-md-12">



<div class="top-sec-image">
<h3 class="fw-bold p-5 lead text-dark"> WE ARE HERE </br>
FOR YOU 
</h3>

</div>

</div>
<div class="col-4 button">
<a  href="use_service_login.php"class="fw-bold ms-5 my-3 btn btn-danger btn-lg">Use our service</a> 

<a href="registrationform.php" class=" fw-bold my-3 ms-5 btn btn-info btn-lg">Register service </a> 


</div>
</div>
</div>

</div>

</div>
</div>

<!--   --->
<div class="top-space">
<div class="container">
<div class="row">

<div class="col-lg-6">

</div>



<div class="col-md-8 m-0">
    <div id="app">
        
    </div>

</div>

<div class="col-md-3 m-0">
    <div id="app">
        <img   src="Images/Download.jpg" class="img-fluid rounded">
    </div>

</div>
</div>

</div>


</div>



<div class="section ">
<div class="container">
<div class="row">
<div  id="p1" class="col-md-6 p-1">
 

<p class="m-4 lead fw-bold text-dark">
MAKE YOUR BUSINESS ONLINE  TODAY

</p>
</div> 
<!---  -->

<div class="col-md-6 p-1">
<div class=" ms-3 app-d ">
<div  id="makebo">
    <img  src="Images/Makebusinessonline.jpg"  class="img-fluid rounded">

</div>

</div>
</div>
</div>
</div>
</div>


 



<div class="section-2 p-5">
<div class="container">
<div class="row">

<div class="col-md-12">
<h2 class="text-center text-light">why us ? </h2>

</div>


<div class="col-md-6">
<div class="service-box">
<span class="fw-bold"><i class="fa-solid fa-mobile-screen me-2"></i><h3 class="lead fw-bold text-white">Convenience</h3></span>
<p  class="lead  text-white">
Any Time Any Where. 
<p>


</div>
</div>








<div class="col-md-6">
<div class="service-box">
<span class="fw-bold"><i class="fa-solid fa-indian-rupee-sign"></i><h3 class="lead fw-bold text-white">Affordable</h3></span>
<p  class="lead  text-white">
Safe and secure payment way . 
<p>


</div>
</div>





<div class="col-md-6">
<div class="service-box">
<span class="fw-bold"><i class="fa-solid fa-people-group"></i><h3 class="lead fw-bold text-white">Community</h3></span>
<p  class="lead  text-white">
One platform for all service . 
<p>
</div>
</div>
</div>
</div>
</div>





<div id="div3"class="section-3 p-5">
<div class="container">
<div class="row">

<div class="col-md-12">
<div class="about-us text-center">
<h2 class="">About us </h2>

<div class="container">
<div class="col-md-12">


</div>
</div>





<p class="lead">
Deogiri Campus, Railway Station Road, Aurangabad, Maharashtra 431005
</p>


<h3><a class="text-muted" href="mailto:rutikjalhare@gmail.com">service@gmail.com</a></h3>

</div>

</div>




<!---    -->
<div class="m-auto col-md-5">
<div class="about-us-2">
<div class="btn-group-lg  ">
  <a  class="text-muted" href="">
<i class="fa-brands fa-facebook m-2"></i>
</a>


  <a class="text-muted" href="">
 <i class="fa-brands fa-instagram m-2"></i>
</a>


  <a  class="text-muted"
 href="" >
<i class="fa-brands fa-twitter m-2"></i>
</a>

  
</div>
  
</div>
</div>
</div>
</div>
</div>
</div>





</body>
</html>

