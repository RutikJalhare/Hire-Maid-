<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>

<style>
.container-fluid{
background-color:white;





}

.row{
height:100vh;

}

</style>
<body>

<div class="container-fluid"> 

<div class="row justify-content-center align-items-center"> 
<div class="col-md-8"> 


<!---   we just copy  it -->
<div id="login" class="card bg-dark text-white" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">

            <div class="mb-md-5 mt-md-4 pb-5">

              <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
              <p class="text-white-50 mb-5">Please enter your login and password!</p>

              <div class="form-outline form-white mb-4">
                <input type="email" id="typeEmailX" class="form-control form-control-lg" />
                <label class="form-label" for="typeEmailX">Email</label>
              </div>

              <div class="form-outline form-white mb-4">
                <input type="password" id="typePasswordX" class="form-control form-control-lg" />
                <label class="form-label" for="typePasswordX">Password</label>
              </div>

              <p class="small mb-5 pb-lg-2"><a class="text-white-50" href="#!">Forgot password?</a></p>

<a href="serviceprovider_profile_page.html"><button class="btn btn-outline-light btn-lg px-5" type="submit">Login</button></a>

              
            </div>

            <div>
              <p class="mb-0">Don't have an account ?  <p onclick="register()" class="text-white-50 fw-bold">Sign Up</p>
              </p>
            </div>

          </div>
        </div>

<!--   Registet page  -->
<div  style="display:none" id="register" class="card bg-dark text-white" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">

            <div class="mb-md-5 mt-md-4 pb-5">

              <h2 class="fw-bold mb-2 text-uppercase">Register</h2>


<div class="form-outline form-white my-3">
                <input type="email" id="typeEmailX" class="form-control form-control-lg" />
                <label class="form-label" for="typeEmailX">Enter Shop Name </label>
              </div>




<div class="input-group my-3"> <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1">+91</span> </div> <input type="text" class="form-control" placeholder="Mobile" aria-label="Username" aria-describedby="basic-addon1"> </div>



<div class="form-outline form-white my-3">

<select class="form-select" multiple aria-label="multiple select example"> <option selected>Apply your service please</option> <option value="1">One</option> <option value="2">Two</option> <option value="3">Three</option> </select>

</div>


 <div class="form-outline my-3">
    <textarea class="form-control" id="form4Example3" rows="4"></textarea>
    <label class="form-label" for="form4Example3">Address</label>
  </div>








<div style="margin-right:300px;"class="my-3">  <input class="form-control" type="file" id="formFile">
<label class="form-label" for="form4Example3">Shop License</label>
 

 </div>



             
              <div class="form-outline form-white my-3">
                <input type="email" id="typeEmailX" class="form-control form-control-lg" />
                <label class="form-label" for="typeEmailX">Email</label>
              </div>













              <div class="form-outline form-white my-3">
                <input type="password" id="typePasswordX" class="form-control form-control-lg" />
                <label class="form-label" for="typePasswordX">Password</label>
              </div>

            

              <button class="btn btn-outline-light btn-lg px-5" type="submit">Register</button>

              
            </div>

            <div>
              <p class="mb-0">Already have an account ? <p onclick="login()" class="text-white-50 fw-bold">Sign In</p>
              </p>
            </div>

          </div>
        </div>


<!-- -->





</div>
</div>
</div>



<script>
function login() {
 document.getElementById("register").style.display = "none";

document.getElementById("login").style.display = "block";


}


function register() {
  document.getElementById("login").style.display = "none";

document.getElementById("register").style.display = "block";


}


</script>





</body>
</html>
