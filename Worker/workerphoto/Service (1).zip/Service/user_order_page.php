<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">


<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<style>
.user-main{
background-color:#2c3e50;
}
#id{

position:relative;
left:-10px;
}

.head-of-profile{
background-color:#2c3e50;

}


#update{
animation-name: example;
  animation-duration: 3s;
animation-iteration-count:1;





}



@keyframes example {
  from {height:20px;color:#2c3e50;}
  to {height:600px;color:white;}
}

 



</style>




<body>
 
<div class="container"> 
<div class="row"> 

<div class="col-md-2">

<div class="logo">
<img src="/storage/emulated/0/htdocs/Laundry_project/depositphotos_268012950-stock-illustration-laundry-service-vector-emblem-in.jpg">
</img>
</div>


</div>
<!--   -->
<div class="col-md-10  text-end">

<div class="logo ">

<a href="#">
<i  class="mt-3 fa-solid fa-envelope fa-3x"></i></a><span  if="noti" class="me-4 badge bg-danger">4</span>

<a href="#"><i class="mt-3 fa-3x fa-solid fa-user"></i>
</a>
<span class=" fw-bold text-muted lead">My profile</span>

</div>

</div>

</div>
</div>


<!-- -->


<div class="user-main">
<div class="container">

<div class="row">
<div class="col-md_12">
<div class="search-bar p-5 ">

<div class="input-group">

  <input type="search" class="form-control rounded" placeholder="Search" aria-label="Search" aria-describedby="search-addon" />

  <button type="button" class=" bg-secondary text-white btn btn-outline-secondary">search</button>
</div>




</div>


</div>


</div>
<!--  first row end here that us search -->
<div class="row">
<div class="col-md-6">

<div class=" card ">

<div class="card-body"> 
<h3 class="card-title">Shop name</h3>


<h4 class="lead" >Service </h4>
 <p class="lead" >

<span> Laundry </span></br>
<span> Steam ironing</span></br>
<span> Dry cleaning </span></br>
</p>
<address class="lead" >
Written by 
Visit us at:<br>
Example.com<br>
Box 564, Disneyland<br>
USA
</address>


<button type="button" class="btn btn-dark btn-lg btn-block">View me </button>


</div>
</div>

</div>
<!---   -->
<div class="col-md-6">

<div class=" card ">

<div class="card-body"> 
<h3 class="card-title">Shop name</h3>


<h4 class="lead" >Service </h4>
 <p class="lead" >

<span> Laundry </span></br>
<span> Steam ironing</span></br>
<span> Dry cleaning </span></br>
</p>
<address class="lead" >
Written by 
Visit us at:<br>
Example.com<br>
Box 564, Disneyland<br>
USA
</address>


<button type="button" class="btn btn-dark btn-lg btn-block">View me </button>


</div>
</div>

</div>



<!--  -->





</div>
<!--  second row end here that us search -->








</div>
</div>







</body>
</html>
