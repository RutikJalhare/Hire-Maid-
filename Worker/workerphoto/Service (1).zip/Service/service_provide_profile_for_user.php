<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">


<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<style>

@media screen and (max-width: 770px)

{
     .logo img{
        width:20%;
        border-radius: 50%;
        }


      }



#id{

position:relative;
left:-10px;
}

.head-of-profile{
background-color:#2c3e50;

}


#update{
animation-name: example;
  animation-duration: 3s;
animation-iteration-count:1;





}



@keyframes example {
  from {height:20px;color:#2c3e50;}
  to {height:600px;color:white;}
}

 



</style>




<body>
 <div  id="profile">
<div  class="container"> 
<div class="row"> 

<div class="col-md-2">

<div class="logo">
<img src="Images/logo.png">
</img>
</div>


</div>
<!--   -->


</div>
</div>


<div class="head-of-profile">
<div class="container">
<div class="row">

 
<div class=" col-sm-6">
<div class=" card ">
<img class="card-img" src="Images/business-woman-standing-cartoon-employee-vector-15325133.jpg"  width="20px;"  height="200px;" alt="Card image cap"> 



<div class="card-body"> 
<h4 class="card-title lead text-dark">Shop name</h4>
<p class="lead">Rutik jalhare
</br>
Mob :+91 957 973 5564</p>
 
<address class="lead" >
Tathagat bhavan
Ambedkar nagar purna 
431511
</address>
<h4 class="fw-bold text-danger">Service</h4>
<p class=" lead">
Laundry. </br>
Dry cleaning. </br>
Steam ironing. </br>

</p>

<button  type="button" class="btn btn-dark btn-lg btn-block">Shop Licence</button> 
</div>
</div>

</div>
<!--- -->



</div>
</div>
</div>
</div>




</script>




</body>
</html>
