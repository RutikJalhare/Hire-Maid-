<?php
/* registration  code only */
ob_start();
include 'database_conn.php';

if(isset($_POST["register"]))
{
//echo "ok";
$shopnameErr="";
$subservicsErr="";
$AddressErr="";
$emailErr="";
$contactErr="";
$passwordErr="";
$cityErr="";

//shop name validation
if(empty($_POST['shopname'])) 
{
 $shopnameErr = "Please enter a valid name";
}
else
{
$shopname = test_input($_POST['shopname']);
}




$service = $_POST['service'];


//code for sub service 

if(empty($_POST['sub_service'])) 
{
$subservicsErr = "Please mention your service ";
}
else
{
  $subservice=Address($_POST['sub_service']);
}



if(empty($_POST['address'])) 
{
$AddressErr = "Mention Address please ";
}
{
 $address=Address($_POST['address']);
}




if(empty($_POST['city'])) 
{
$cityErr = "This field is required";
}
else
{
//echo $email=$_POST['email'];
 $city = $_POST['city'];
}




if(empty($_POST['email'])) 
{
$emailErr = "This field is required";
}
else
{
//echo $email=$_POST['email'];
 $email = test_input($_POST['email']);
}





if(empty($_POST['contact'])) 
{
$contactErr = "This field is required";
}
else
{
 $contact = test_input($_POST['contact']);

$contactErr=validating($contact);

}


  $image_name=$_FILES['ownphoto']['name'];

//upload image only when image is selected
  $source_path=$_FILES['ownphoto']['tmp_name'];
  $destination_path="./ownership_certificate/".$image_name;
         $upload=move_uploaded_file($source_path,$destination_path) ;




//validating password 
//echo  $password=$_POST['password'];
//validating password 
 $password=$_POST['password'];
$number = preg_match('@[0-9]@', $password);
$lowercase = preg_match('@[a-z]@', $password);
$specialChars = preg_match('@[^\w]@', $password);

if(strlen($password) < 5 || !$number  || !$lowercase || !$specialChars) 
{
$passwordErr="Password must have 5 characters and  contain at least one number, one lower case letter and one special character.";
}
else
{
 $password=$password;
}

/*
$shopnameErr="";
$subservicsErr="";
$AddressErr="";
$emailErr="";
$contactErr="";
$passwordErr="";


*/

/*
if($shopnameErr || $passwordErr || $subservicsErr || 
$AddressErr || $emailErr  || $contactErr =="") 
{
echo "correct shop...".$shopname;
echo "main_service..".$service;
echo "sub service...".$subservice;
echo "email...".$email;
echo "password..".$password;
echo "contact...".$contact;
echo "address..".$address;


}
else
{

echo "shop name error...".$shopnameErr;
echo "password error ..".$passwordErr;
echo "contact err..".$contactErr;
echo "sub service error ..".$subservicsErr;
echo "email error..".$emailErr;
echo "address error ...".$AddressErr;
}

*/

if(empty($shopnameErr) && empty($subservicsErr)  && empty($AddressErr)     &&
empty($contactErr)     &&
empty($passwordErr)    &&
empty($cityErr)
) 
{
//only correct data is come here now 
$shopname;
$subservice;
$address;
$contact;
$password;
$city;
$ownphoto;


$sql3="SELECT * FROM owener WHERE email='$email' AND password='$password'";

$res3=mysqli_query($conn,$sql3) ;

//4.count rows wheather the user exist or not 
$count3=mysqli_num_rows($res3) ;
if($count3 > 0) 
{
?>



<h2 class="lead fw-bold  text-danger">
<?php echo "Sorry...email Already taken";?>
</h2>
<?php

}
else
{

$sql="INSERT INTO owener SET
shop_name='$shopname',
main_ser='$service', 
sub_ser='$subservice',
address='$address',
city='$city', 
email='$email',
contact='$contact', 
shop_lic='$image_name', 
password='$password'
";

$res=mysqli_query($conn,$sql)or die(mysqli_error($conn)) ;
if($res==true)
{


?>
<h2 class="lead  text-success">
<?php echo "You are successfully registered.Thank You";?>
</h2>
<?php


}
else
{


?>
<h2 class="lead  text-danger">
<?php echo "Technical Error ! Please try again later. ";?>
</h2>

<?php
//echo "not inserted";
}

/*
echo "correct shop name....".$shopname;
echo "correct sub_service...".$subservice;
echo "correct address ...".$address;
echo "correct contact ...".$contact;
echo "correct password ...".$password;

*/
}
}
else
{
/*
echo "Incorrect shop name".$shopnameErr;
echo "Incorrect sub service..".$subservicsErr;
echo "Incorrect Address..".$AddressErr;

echo "Incorrect Contact ..".$contactErr;
echo "Incorrect password ..".$passwordErr;


*/
?>

<h2 class="lead  text-danger">
<?php echo "Registration failed ! Please make sure that data is valid. ";?>
</h2>


<?php
}



//end of main if 
}


//function for checking invalid data 

function validating($phone){ if(preg_match('/^[0-9]{10}+$/', $phone)) 
{

}
else
{
$invalid="invalid contact";
return $invalid;
}
} 





function test_input($data) 
{
$data = trim($data);
$data = stripslashes($data);
$data = htmlspecialchars($data);
return $data;
}

function RemoveSpecialChar($str) 
{
$res = str_replace( array('1','2','3',   
'4', '5', '6', '7', '8', '9', '0', 


',','.','!','? ',"'",'"', ':','*','/', '&','-','+','(','#','₹','_' ,'@','\'', '"',
	',' , ')' ,';', '<', '>' ), ' ','=',$str);
	return $res;
}

function Address($str) 
{
$res = str_replace( array(
',','.','!','? ',"'",'"', ':','*','/', '&','-','+','(','#','₹','_' ,'@','\'', '"',
	',' , ')' ,';', '<', '>' ), ' ', $str);
	return $res;
}
?>

<!--
only login php begin from here 
-->

<?php
ob_start();
$wrong_data="";


if(isset($_POST["login"]))
{


//prevention of sql injections
$email =mysqli_real_escape_string ($conn,$_POST['email']);

//RemoveSpecialChar
$password=mysqli_real_escape_string ($conn,$_POST['password']);



$sql2="SELECT * FROM owener WHERE email='$email' AND password='$password'";

//3.execite the query 



$res2=mysqli_query($conn,$sql2) ;

//4.count rows wheather the user exist or not 
$count2=mysqli_num_rows($res2) ;
if($count2 > 0) 
{

while($rows=mysqli_fetch_assoc($res2))
{
 $id=$rows['id'];
}

header("location:http://0.0.0.0:8080/Main_project/Service/serviceprovider_profile_page.php?id=$id");

}
else
{
$wrong_data="Invalid Email or password ";

//echo "Not Available";

}




//End of main if login button 

}


?>





<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>


<body>
<!--     login form start -->




<section id="login" class="vh-100 gradient-custom">
  <div class="container py-2 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-6 col-lg-6 col-xl-5">
        <div class="card bg-dark text-white" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">

            <div class="mb-md-5 mt-md-4 pb-5">

              <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
              <p class="text-white-50 mb-5">Please enter your login and password!</p>

<form method="POST">

 <p class="text-danger"><?php echo $wrong_data; ?></p>

              <div class="form-outline form-white mb-4">
                <input type="email" name="email" class="form-control form-control-lg" />
                <label class="form-label" for="typeEmailX">Email</label>
              </div>

              <div class="form-outline form-white mb-4">
                <input type="password" name="password" class="form-control form-control-lg" />
                <label class="form-label" for="typePasswordX">Password</label>
              </div>

              <p class="small mb-5 pb-lg-2"><a class="text-white-50" href="#!">Forgot password?</a></p>


              <!--<a href="serviceprovider_profile_page.php"><button class="btn btn-outline-light btn-lg px-5" type="submit">Login</button></a>-->

<input class="btn btn-outline-light btn-lg px-5" name="login" value="Login" type="submit">



</form>

              

            </div>

            <div onclick="register()">
              <p class="mb-0">Don't have an account? <a href="#!" class="text-white-50 fw-bold">Sign Up</a>
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>











<!-- login form end here -->

<section id="register" style="display: none;" class="vh-100 gradient-custom">
  <div class="container py-2 ">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-9">
        <div class="card bg-dark text-white" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">

            <div class="mb-md-2 mt-md-4 pb-3">

              <h2 class="fw-bold mb-2 text-start ">Create Account</h2>

<form method="POST" enctype="multipart/form-data">

              <div class="col-md-12 mb-2">
  
                <div class="form-outline">
                  <input type="text" id="firstName" name="shopname" class="form-control form-control-lg" />
                  <label class="form-label" for="firstName">Shop Name</label>
</br>
<span  class="lead error text-danger">*<?php echo $shopnameErr;?></span>
                </div>

              </div>
          


              <div class="col-md-12 mb-2 d-flex align-items-center">

                <div class="form-outline w-100">


                  <select name="service" class="form-select" aria-label="Default select example">
                    <option value="Electronic Repairs">Electronic Repairs</option> <option value="Mechanics">Mechanics</option> <option value="Laundry Service">Laundry Service</option> 
                    <option value="Online Service">Online Service </option>
                    <option value="Delivary Service">Delivary Service </option>
                    <option value="Medical Service">Medical Service </option>
                    
                  </select>


             
                 

  

<label class="form-label" for="firstName"> Apply Your Services</label>

                  
                </div>

              </div>





<div class="form-outline my-2">
  <textarea placeholder="Mention Service Here " name="sub_service" class="form-control" rows="4"></textarea>
   </br>
   <span class="lead error text-danger">*<?php echo $subservicsErr;?></span>
              
 </div>

<!--   -->
 <div class="col-md-12 mb-2">
<select name="city" class="form-select" required>

<option value="">Select city</option>
<option value="Aurangabad">Aurangabad</option> <option value="Nanded">Nanded</option> <option value="Mumbai">Mumbai</option> </select>

  </br>
   <span class="lead error text-danger">*<?php echo $cityErr;?></span>

                 
 
  <div class="form-outline my-2">


</div>


</div>





<!-- -->






 <div class="col-md-12 mb-2">

                 
 
  <div class="form-outline my-2">
<textarea name="address" placeholder="Enter Address Here " class="form-control"  rows="4"></textarea>
</br>
<span class="lead error text-danger">*<?php echo $AddressErr;?></span>
</div>


</div>


<div class="row">


<div class="col-md-6 mb-4 pb-2">
  <input type="email" name="email" placeholder="Your Email" class="form-control form-control-lg" /required>
</br>
<span class="lead error text-danger">*<?php echo $emailErr;?></span>                  


</div>













<div class="col-md-6 mb-4 pb-2">
  <input type="number" name="contact" placeholder="phone number" class="form-control form-control-lg" />
</br>
<span class="lead error text-danger">*<?php echo $contactErr;?></span> 
             
</div>
</div>


<div class="row">
<div class="col-md-6 mb-4 pb-2">
  <input  class="form-control" type="file" name="ownphoto" required><p class="lead text-danger" >Upload Shop License</p>
             
</div>



<div class="col-md-6 mb-4 pb-2">
  <input id="myInput" type="password" name="password" placeholder="Create password" class="form-control form-control-lg" /> 
<span class="lead error text-danger">*<?php echo $passwordErr;?></span> 




 
 
  <div class="form-check mt-3"> <input onclick="myFunction()" class="form-check-input" type="checkbox"/> 
    <label class="me-5 form-check-label text-start" for="form2Example31">Show Password</label> </div>
</div></div>


 


<div class="col-md-12 mb-4 pb-2">
  <input type="submit" name="register" type="button" class="p-3 btn-primary btn-lg btn-block" value="Register">

     
</div>




</form>



<div onclick="login()"><p class="fw-bold">Already have Account ? Login here
</p>
</div>




            </div>

       
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


















<script>
function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

</script>










</body>

<script>
function login()
 { document.getElementById("register").style.display = "none";

document.getElementById("login").style.display = "block";


}


function register()
 {
    document.getElementById("register").style.display = "block";

document.getElementById("login").style.display = "none";


}

</script>
</html>

