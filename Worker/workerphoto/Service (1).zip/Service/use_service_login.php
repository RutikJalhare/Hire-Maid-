<?php
if(isset($_FILES['userphoto']['name'])) 
{
  $image_name=$_FILES['userphoto']['name'];

//upload image only when image is selected
  $source_path=$_FILES['userphoto']['tmp_name'];
  $destination_path="./mimages/".$image_name;
         $upload=move_uploaded_file($source_path,$destination_path) ;

if($upload==true) 
{
$userphoto = $image_name;
//echo "upload ";
}
else
{
//$image_name="$image_name";
//$image_name="not upload";
//echo "not upload";
$userphotoErr="Not Upload";
}

}

else
{
//echo "not added";
$userphotoErr="Not selected";
}
?>
<?php
ob_start();
include 'database_conn.php';

if(isset($_POST['register'])) 
{

$nameErr="";
$AddressErr="";
$contactErr="";
$emailErr="";
$passwordErr="";

/*
echo $name=$_POST['name'];
echo $address=$_POST['address'];
echo $userphoto=$_POST['userphoto'];
echo $name=$_POST['phone'];
echo $address=$_POST['email'];
echo $userphoto=$_POST['password'];
*/
//validation for user  name 
if(empty($_POST['name'])) 
{
$nameErr = "This field is required";
}
else
{
 $name = RemoveSpecialChar($_POST['name']);
}


//validation for address
if(empty($_POST['address'])) 
{
$AddressErr = "This field is required";
}
else
{
$address = Address($_POST['address']);
}

//validation on selecting user image
/*$userphoto=$_POST['userphoto'];
$source_path=$_FILES['userphoto']['tmp_name'];
  $destination_path="../Custom-img/".$userphoto;
       $upload=move_uploaded_file($source_path,$destination_path) ;

*/










//validation for contact 
if(empty($_POST['phone'])) 
{
$contactErr = "Please Enter valid contact.";
}
else
{

$contact = test_input($_POST['phone']);
$contactErr=validating($contact);
}

//validation for email
if(empty($_POST['email'])) 
{
$emailErr = "This field is required";
}
else
{
//echo $email=$_POST['email'];
  $email = test_input($_POST['email']);
}

//validation for password
$password=$_POST['password'];
$number = preg_match('@[0-9]@', $password);
$lowercase = preg_match('@[a-z]@', $password);
$specialChars = preg_match('@[^\w]@', $password);

if(strlen($password) < 5 || !$number  || !$lowercase || !$specialChars) 
{
$passwordErr="Password must have 5 characters and  contain at least one number, one lower case letter and one special character.";
}
else
{
 $password=$password;
}

//now we are checking is all the correct data is field or not.. if any one filed have error then data will not inserted and error will show 
if(empty($nameErr) && empty($AddressErr)  && empty($contactErr)     &&
empty($emailErr)     &&
empty($passwordErr) &&
empty($userphotoErr) 
)
{
//only correct data 
$name;
$address;
$contact;
$email;
$password;
$userphoto;

//validation that user is already registet Or not 
$sql3="SELECT * FROM user WHERE email='$email' AND password='$password'";

$res3=mysqli_query($conn,$sql3) ;

//4.count rows wheather the user exist or not 
$count3=mysqli_num_rows($res3) ;
if($count3 > 0) 
{
?>
<h2 class="lead  fw-bold text-danger">
<?php echo "Sorry... Username Already taken ! ";?>
</h2>
<?php
}
else
{





//entering data in database 
$sql="INSERT INTO user SET
name='$name',
address='$address', 
photo='$userphoto',
contact='$contact', 
email='$email',
password='$password'
";

$res=mysqli_query($conn,$sql)or die(mysqli_error($conn)) ;
if($res==true)
{

//registration successful
?>
<h2 class="lead fw-bold text-success">
<?php echo "You are successfully registered.Thank You";?>
</h2>
<?php


}
else
{
//data not enter in database 
?>
<h2 class="lead fw-bold
 text-danger">
<?php echo "Technical Error ! Please try again later. ";?>
</h2>

<?php



}




}
}
else
{
//something  is wrong 
?>

<h2 class="lead  fw-bold
text-danger">
<?php echo "Registration failed ! Please make sure that enter data is valid. ";?>
</h2>
<?php
}





//end of main if registration button
}


//login page code start
if(isset($_POST['login'])) 
{
$email =mysqli_real_escape_string ($conn,$_POST['email']);

//RemoveSpecialChar
$password=mysqli_real_escape_string ($conn,$_POST['password']);
//echo "login";

$sql2="SELECT * FROM user WHERE email='$email' AND password='$password'";

//3.execite the query 
$res2=mysqli_query($conn,$sql2) ;

//4.count rows wheather the user exist or not 
$count2=mysqli_num_rows($res2) ;
if($count2 > 0) 
{
//redirect to next page if proper user name & password  with his id 
while($rows=mysqli_fetch_assoc($res2))
{
 $id=$rows['id'];
}

header("location:http://0.0.0.0:8080/Main_project/Service/main_page_for_user.php?id=$id");




}
else
{
?>

<h2 class="lead  fw-bold
text-danger">
<?php echo "Invalid User name Or Password.";?>
</h2>


<?php
}





}




function validating($phone){ if(preg_match('/^[0-9]{10}+$/', $phone)) 
{
//means no error everything is true
}
else
{
$invalid="invalid contact";
return $invalid;
}
} 





function test_input($data) 
{
$data = trim($data);
$data = stripslashes($data);
$data = htmlspecialchars($data);
return $data;
}

function RemoveSpecialChar($str) 
{
$res = str_replace( array('=','1','2','3',   
'4', '5', '6', '7', '8', '9', '0', 
',','.','!','? ',"'",'"', ':','*','/', '&','-','+','(','#','₹','_' ,'@','\'', '"',
	',' , ')' ,';', '<', '>' ), ' ',$str);
return $res;
}

function Address($str) 
{
$res = str_replace( array(
',','.','!','? ',"'",'"', ':','*','/', '&','-','+','(','#','₹','_' ,'@','\'', '"',
	',' , ')' ,';', '<', '>' ), ' ', $str);
	return $res;
}


?>
<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>


<body>
<!--     login form start -->

<section id="login" class="vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card bg-dark text-white" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">

            <div class="mb-md-5 mt-md-4 pb-5">

              <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
              <p class="text-white-50 mb-5">Please enter your login and password!</p>

<form method="POST">

              <div class="form-outline form-white mb-4">
                <input type="email" name="email" class="form-control form-control-lg" />
                <label class="form-label" for="typeEmailX">Email</label>
              </div>

              <div class="form-outline form-white mb-4">
                <input type="password" name="password" class="form-control form-control-lg" />
                <label class="form-label" for="typePasswordX">Password</label>
              </div>

              <p class="small mb-5 pb-lg-2"><a class="text-white-50" href="#!">Forgot password?</a></p>







              <!--<a href="main_page_for_user.php"><button class="btn btn-outline-light btn-lg px-5" type="submit">Login</button></a>

    -->   
<input type="submit" name="login" class="btn btn-outline-light btn-lg px-5" value="Login" >

     

            </div>
</form>


<div onclick="login()"><p class="fw-bold">Don't have Account ? Sign here
</p>
</div>




         




          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- login form end here -->

<section id="register" style="display:none" class="bg-dark vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row justify-content-center align-items-center h-100">
      <div class="col-12 col-lg-9 col-xl-7">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Create Account</h3>
    

<form method="POST" enctype="multipart/form-data">

              <div class="row">
                <div class="col-md-12 mb-4">

                  <div class="form-outline">
                    <input placeholder="Enter Name" type="text" name="name" class="form-control form-control-lg" />
</br>
<span  class="lead error text-danger">*<?php echo $nameErr;?></span>
                  
                  </div>





                </div>
                <!--<div class="col-md-6 mb-4">

                  <div class="form-outline">
                    
                    
                  </div>

                </div>-->
              </div>

              <div class="row">
                

 <div class="col-md-12 mb-4">

                 

                   <div class="form-outline my-3">
    <textarea  placeholder="Enter Address Here " class="form-control" name="address" rows="4"></textarea>

</br>
<span  class="lead error text-danger">*<?php echo $AddressErr;?></span>

  </div>


</div>



<!---    -->
<div class="col-md-6 mb-4 pb-2">
       <input class="form-control" type="file" accept="image/*"
name="userphoto" >
       <label for="basic-url">Upload Photo</label> 
</br>
<span  class="lead error text-danger">*<?php echo $photoErr;?></span>
         
</div>

<div class="col-md-6 mb-4 pb-2">
       <div class="input-group "> <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1">+91</span> </div> <input type="text" class="form-control" placeholder="Phone"
name="phone" 
aria-label="Username" aria-describedby="basic-addon1"> </div> 

</br>
<span  class="lead error text-danger">*<?php echo $contactErr;?></span>

                  
</div>

<!---   -->
<div class="col-md-6 mb-4 pb-2">
       <input type="email" name="email" placeholder="Your Email" class="form-control form-control-lg" />
</br>
<span  class="lead error text-danger">*<?php echo $emailErr;?></span>               


</div>



<div class="col-md-6 mb-4 pb-2">
       <input type="password" name="password" placeholder="Create Password" class="form-control form-control-lg" />

</br>
<span  class="lead error text-danger">*<?php echo $passwordErr;?></span>               

                  
</div>








<div class="col-md-12 mb-4 pb-2">
       <input value="Register" type="submit" name="register" class="p-3 btn-primary btn-lg btn-block">
                  
</div>

<div onclick="register()"><p class="fw-bold">Already have Account ? Login here
</p>
</div>



  <div>
            

             

                </div>
              </div>

             
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>




</body>




<script>
function login() { document.getElementById("register").style.display = "block";

document.getElementById("login").style.display = "none";


}


function register() { document.getElementById("register").style.display = "none";

document.getElementById("login").style.display = "block";


}



</script>
</html>



