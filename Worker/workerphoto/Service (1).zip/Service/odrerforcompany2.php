<div  id="od" class=" p-4 order-div">



<div class="container">

<i onclick="return_to_user_pro()" class="fa-solid fa-arrow-left-long fa-3x"></i>

<div class="row">

<div class="text-center col-md-6">
<div class="order-info">



<div class="card"> 

<img  height="170px" class="card-img rounded-circle" src="
/storage/emulated/0/htdocs/Laundry_project/business-woman-standing-cartoon-employee-vector-15325133.jpg" alt="Card image cap"> 

<div class="card-body"> 

<span class="btn btn-primary pill" >Rutik jalhare</span>
<p class="card-text fw-bold">1 T-shirt ,1 suit , 2 Kurta .</p> 

<address class="lead" >
Gate No. 2 , MGM Campus, N-6, Cidco, Aurangabad,


</address>


<input  type="submit"  value="Accept order" class="btn btn-block btn-danger">


</div> 

</div>


</div>
</div>




<!--- -->






<div class="text-center col-md-6">
<div class="order-info">
<div class="card"> 

<img  height="170px" class="card-img rounded-circle" src="
/storage/emulated/0/htdocs/Laundry_project/business-woman-standing-cartoon-employee-vector-15325133.jpg" alt="Card image cap"> 

<div class="card-body"> 

<span class="btn btn-primary pill" >Rutik jalhare</span>
<p class="card-text fw-bold">1 T-shirt ,1 suit , 2 Kurta .</p> 

<address class="lead" >
Gate No. 2 , MGM Campus, N-6, Cidco, Aurangabad,


</address>

<input type="submit"  value="Accept order" class="btn btn-block btn-danger">
</div> 
</div>
</div>
</div>

</div>

<!----+ first row end here -->

<div clas="row">

<div clas="col-md-12">

<div clas="table-row">

<table class="table lead mt-5"> 

<thead> 
<tr> 
<th scope="col">Name</th> 
<th scope="col">Contact</th> 
<th scope="col">Address</th> 
<th scope="col">Amount</th> 
<th scope="col">status</th>
<th scope="col">status</th>
 
</tr> 

</thead>
<tbody>
<tr> 
<th scope="row">Rutik jalhare</th> <td>9579735594</td> 
<td>Ambedkar nagar purna</td> <td>380</td>

<td>ordered</td>
<td ><select class="btn btn-block btn-warning form-select" aria-label="Default select example"> <option selected>progress</option> <option value="1">Delivered</option> </select></td>


</tr> 






<tbody>
<tr> 
<th scope="row">Rutik jalhare</th> <td>9579735594</td> 
<td>Gate No. 2 , MGM Campus, N-6, Cidco, Aurangabad</td> <td>380</td>
<!--<td><button class="btn btn-success">Delivered</button></td>

-->
<td>ordered</td>
<td ><select class="btn btn-block btn-danger form-select" aria-label="Default select example"> <option selected>progress</option> <option value="1">Deliveredipqrpiiruqq</option> </select></td>



</tr> 







<tbody>
<tr> 
<th scope="row">Rutik jalhare</th> <td>9579735594</td> 
<td>Ambedkar nagar purna</td> <td>380</td>
<td>ordered</td>
<td ><select class="btn btn-block btn-info form-select" aria-label="Default select example"> <option selected>progress</option> <option value="1">Delivered</option> </select></td>



</tr> 





 
</tbody>
</table>
</div>

</div>






</div>




</div>
</div>