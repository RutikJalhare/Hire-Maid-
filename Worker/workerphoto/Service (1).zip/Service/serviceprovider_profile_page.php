<?php
include 'database_conn.php';
$id=$_GET['id'];

session_start();
$_SESSION["id"] = $id;

if(isset($_POST["save_change"]))
{

$subservicsErr="";
$AddressErr="";
$contactErr="";
$photoErr="";


$service = $_POST['service'];
//$ownphoto=$_POST['photo'];
  $image_name=$_FILES['photo']['name'];

//upload image only when image is selected
  $source_path=$_FILES['photo']['tmp_name'];
  $destination_path="./ownership_certificate/".$image_name;
         $upload=move_uploaded_file($source_path,$destination_path) ;



if(empty($_POST['sub_service'])) 
{
$subservicsErr = "Please mention your service ";
}
else
{
 $subservice=RemoveSpecialChar($_POST['sub_service']);
}


if(empty($_POST['address'])) 
{
 $AddressErr = "Mention Address please ";
}
{
  $address=Address($_POST['address']);
}


if(empty($_POST['contact'])) 
{
$contactErr = "This field is required";
}
else
{
$contact = test_input($_POST['contact']);

$contactErr=validating($contact);

}


if(empty($subservicsErr) && empty($AddressErr)  && empty($contactErr))
{
$subservice;
$address;
$contact;
$service;
$ownphoto;

$sql="UPDATE owener SET
main_ser='$service', 
sub_ser='$subservice',
address='$address',
contact='$contact', 
shop_lic='$image_name' WHERE id=$id
";

$res=mysqli_query($conn,$sql)or die(mysqli_error($conn)) ;


if($res==true)
{
?>
<h2 class="lead  text-success">
<?php echo "Updated successfully .Thank You";?>
</h2>
<?php
}
else
{
?>
<h2 class="lead  text-danger">
<?php echo "Technical Error! Try again later ";?>
</h2>
<?php
}




}

else
{
?>
<h2 class="lead  text-danger">
<?php echo "Please make sure enter data is correct";?>
</h2>
<?php
}






/*
echo $service=$_POST["service"];
echo $sub_service=$_POST["sub_service"];
echo $address=$_POST["address"];
echo $cintact=$_POST["contact"];
echo $photo=$_POST["photo"];
*/


//End of main if 
}

function test_input($data) 
{
$data = trim($data);
$data = stripslashes($data);
$data = htmlspecialchars($data);
return $data;
}

function RemoveSpecialChar($str) 
{
$res = str_replace( array('1','2','3',   
'4', '5', '6', '7', '8', '9', '0', 


',','.','!','? ',"'",'"', ':','*','/', '&','-','+','(','#','₹','_' ,'@','\'', '"',
	',' , ')' ,';', '<', '>' ), ' ', $str);
	return $res;
}


function validating($phone){ if(preg_match('/^[0-9]{10}+$/', $phone)) 
{

}
else
{
$invalid="invalid contact";
return $invalid;
}
} 




function Address($str) 
{
$res = str_replace( array(
',','.','!','? ',"'",'"', ':','*','/', '&','-','+','(','#','₹','_' ,'@','\'', '"',
	',' , ')' ,';', '<', '>' ), ' ', $str);
	return $res;
}
?>


<!--- query to displaying owener 
infromation  start from here --->
<?php
$sql4="SELECT * FROM  owener WHERE id =$id";
$res4=mysqli_query($conn,$sql4) ;


$count4=mysqli_num_rows($res4) ;


if($count4>0)
{

while($rows=mysqli_fetch_assoc($res4))
{
$shop_name=$rows['shop_name'];
$main_ser=$rows['main_ser'];
$sub_ser=$rows['sub_ser'];
$city=$rows['city'];
$address=$rows['address'];
$email=$rows['email'];
$contact=$rows['contact'];
$shop_lic=$rows['shop_lic'];



}
}
?>







<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">


<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

<style>

#id{

position:relative;
left:-10px;
}

.head-of-profile{
background-color:#2c3e50;

}


#update{
animation-name: example;
  animation-duration: 3s;
animation-iteration-count:1;





}



@keyframes example {
  from {height:20px;color:#2c3e50;}
  to {height:600px;color:white;}
}

 



</style>




<body>
 <div  id="profile">
<div  class="container"> 
<div class="row"> 

<div class="col-md-2">

<div class="logo">
<img src="Images/logo.png">
</img>
</div>


</div>
<!--   -->
<div class="col-md-10   text-end">

<div class="logo ">





<!--<a href="order__placed__in__company.php?id=<?php echo $id;?>">
<i 
class="mt-3 fa-solid fa-envelope fa-3x"></i></a><span 
 id="noti" class="badge bg-danger">4</span>
-->
<a href="order__placed__in__company.php">
<i 
class="mt-3 fa-solid fa-envelope fa-3x"></i></a><span 
 id="noti" class="badge bg-danger"></span>


</div>

</div>

</div>
</div>


<div class="head-of-profile">
<div class="container">
<div class="row">







<div class=" col-md-4">
<div class=" card ">
<img class="card-img" src="Images/business-woman-standing-cartoon-employee-vector-15325133.jpg"  width="20px;"  height="200px;" alt="Card image cap"> 



<div class="card-body"> 
<h4 class="card-title"><?php echo $shop_name?></h4>
<p class=" lead ">
Mob :<?php echo $contact?></p>
 
<address>
<?php echo $address;?>
</br>
<?php echo $city ;?>
</address>
<h4 class="fw-bold text-danger">Service</h4>
<h5 class="fw-bold text-secondary"><?php echo $main_ser;?></h5>

<p class=" lead">
<?php echo $sub_ser;?>

</p>

<button onclick="showupdate()" type="button" class="btn btn-dark btn-lg btn-block">Edit</button> 
</div>
</div>

</div>
<!--- -->
<div class="col-md-8">
<div  style="display:none" id="update" class="card bg-dark text-white" style="border-radius: 1rem;">

          <div class="card-body p-5 text-center">


<!--<i class="  fa-solid fa-rectangle-xmark"></i>
-->

<i onclick="hideupdate()" style="position:relative;top:-30px;left:200px;" class="fa-solid fa-xmark"></i>

<form enctype="multipart/form-data" method="POST">

<h2 class="fw-bold lead">shop name</h2>






  <div class="form-outline w-100">


    <select name="service" class="form-select" aria-label="Default select example">
      <option value="Electronic Repairs">Electronic Repairs</option> <option value="Mechanics">Mechanics</option> <option value="Laundry Service">Laundry Service</option> 
      <option value="Online Service">Online Service </option>
      <option value="Delivary Service">Delivary Service </option>
      <option value="Medical Service">Medical Service </option>
      
    </select>

<label class="form-label" for="firstName"> Apply Your Services</label>

    
  </div>

  <div class="form-outline my-2">
    <textarea placeholder="Mention Service Here " name="sub_service" class="form-control" rows="4"></textarea>
     </br>
     <span class="lead error text-danger">*<?php echo $subservicsErr;?></span>
                
   </div>


  <!-- Message input -->
  <div class="form-outline my-3">
    <textarea class="form-control"  placeholder="Enter Addresss Here " name="address" rows="2"></textarea>
    <span class="lead error text-danger">*<?php echo $AddressErr;?></span>
  </div>


<div class="input-group my-3"> <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1">+91</span> </div> <input type="text" class="form-control" placeholder="Mobile"
name="contact" 
aria-label="Username" aria-describedby="basic-addon1"> 
</div>
<span class="lead error text-danger">*<?php echo $contactErr;?></span>

<div style="margin-right:200px;"class="my-3">
<input class="form-control" type="file" name="photo" required>
<label class="form-label" for="form4Example3">Shop License</label>
 </div>





  <!-- Submit button -->

<input type="submit" name="save_change" value="save changes" class="btn btn-primary btn-lg btn-block">


 
</form>

        

           </div>
           </div>
           </div>


</div>
</div>
</div>
</div>



<script>


function showupdate() {


document.getElementById("update").style.display = "block";


}

function hideupdate() {
document.getElementById("update").style.display = "none";


}


</script>




</body>
</html>
