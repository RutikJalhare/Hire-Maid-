<?php
include 'database_conn.php';
 $id=$_GET['id'];
$userid=$id;

?>

<!Doctype html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
<link href="laundry.css" rel="stylesheet">

  

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

<!--  css for  success icon pop up  -->
<style>
#error, #success{
text-align: center;
        
        
}
 
.success{
        text-align: center;
        padding: 40px 0;
        background: #EBF0F5;
      }

.error{
        text-align: center;
        padding: 40px 0;
        background: #EBF0F5;
      }



.card i {
        color: #9ABC66;
        font-size: 100px;
        line-height: 200px;
        margin-left:-15px;
      }
      .card {
        background: white;
        padding: 30px;
        border-radius: 4px;
        box-shadow: 0 2px 3px #C8D0D8;
        display: inline-block;
        margin: 0 auto;
      }
    </style>






<script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>



</head> 
<!--
<div class="top">

</div>

<select class="form-select" multiple aria-label="multiple select example"> <option selected>Open this select menu</option> <option value="1">One</option> <option value="2">Two</option> <option value="3">Three</option> </select>



-->
<body>
<div class="main1">
<div class="container">




<div class="row">

<div class="col-md-12 text-end">



<!--<a class="mt-3" href="#">
<i  class="fa-solid fa-envelope fa-3x"></i></a><span  id="noti" class="me-3 badge bg-danger">4</span>
-->


<a class="mx-3" href="user_profile_page.php?id=<?php echo $id ?>">
<i class=" fa-solid fa-user fa-3x"></i></a>


<a href="order_by_ussr.php?id=<?php echo $id ?>">
<i 
  class="mt-3 fa-solid fa-envelope fa-3x"></i></a><span 
 id="noti" class="badge bg-danger"></span>







</div>


</div>

<form method="POST">
<div class="row">










<div 
class="col-md-4 p-4">
<select name="service" class="form-select"  aria-label="multiple select example"> <option selected>Choose service</option> <option value="Mechanics">Mechanical</option> <option value="Electronic Repairs">Electrician</option> value="Online Service">Online Service </option>
                    <option value="Delivary Service">Delivary Service </option>
                    <option value="Medical Service">Medical Service </option>
<option value="Online Service">Tech Service </option>

<option value="Laundry Service">Laundry</option>


 </select>
</div>

<!-- sselect country-->
<div 
class="col-md-4 p-4">
<select name="city" onchange="random_function()" id="input" class="form-select"  aria-label="multiple select example"> <option selected>Choose City </option> <option value="Aurangabad">Aurangabad</option> <option value="Nanded">Nanded</option> <option value="Mumbai">Mumbai</option> </select>
</div>

<!-- select area -->
<script>
function random_function()
{
var a=document.getElementById("input").value;
if(a==="Aurangabad")
{
var arr=["Kranti chowk","Croma Multiplex","Aurangpura","J Tower"];
                
}
else if(a==="Nanded")
{
var arr=["Ambedkar nagar","Colleage Line","Shivaji Chowk","Siddhart Nagar"];
}

else if(a==="Mumbai")
{
var arr=["Jay Prakash Nagar","Goregaon west","Rajiv Nagar ","kamble chawl"];
}

             
var string="";
             
                for(i=0;i<arr.length;i++)
{
                    string=string+"<option value="+arr[i]+">"+arr[i]+"</option>";
                
document.getElementById("output").innerHTML=string;
}
     

}
        </script>




<!--
<div 
class="col-md-4 p-4">
<select class="form-select" multiple aria-label="multiple select example"> <option selected>Apply Fillter </option> <option value="1">One</option> <option value="2">Two</option> <option value="3">Three</option> </select>
</div>
-->
<div 
class="col-md-4 p-4">
<select name="area" id="output" class="form-select"  aria-label="multiple select example">  </select>
</div>





<div class="col-md-12 mt-3">
<input class="mb-4 fw-bold  btn btn-danger" type="submit" name="filter" value="Apply Filter">
</div>


</div>




</form>

</div>
</div>


<!--- --->
<?php
$id=$_GET['id'];
if(isset($_POST['filter']))
{
//echo "ok";
$service=$_POST['service'];
$city=$_POST['city'];
$area=$_POST['area'];

//$sql2="SELECT * FROM owener WHERE email='$email' AND password='$password'";

$sql="SELECT * FROM owener WHERE main_ser='$service' AND city='$city'";


//$sql="SELECT * FROM  owener ";
$res=mysqli_query($conn,$sql) ;


$count=mysqli_num_rows($res) ;


if($count>0)
{

while($rows=mysqli_fetch_assoc($res))
{
$popup=$rows['id'];
$shop_name=$rows['shop_name'];
$main_ser=$rows['main_ser'];$sub_ser=$rows['sub_ser'];
$city=$rows['city'];
$address=$rows['address'];
$email=$rows['email'];
$contact=$rows['contact'];
$shop_lic=$rows['shop_lic'];
?>
<div class="col-md-6 mt-3 ">
  <div class=" card ">
  
  <div class="card-body"> 
  <form method="POST">
  <h4 class="fw-bold text-danger card-title"><?php echo $shop_name ;?></h4>
  <p class=" lead ">
  
  Mob :+91 <?php echo $contact?></p>
   
  <address>
  <?php echo $address." ". $city?>
  </address>


  <h4 class="fw-bold text-danger">Service</h4>
  <p class=" lead">
  <?php echo $sub_ser;?>
  
  </p>
  
 <a href="<?php echo SITEURL;?>ownership_certificate/<?php echo $shop_lic;?>" class=" border btn btn-dark" download>Shop Licence</a>

 <!--
 src="<?php echo SITEURL;?>mimages/<?php echo $userphoto;?>
   -

<a class=" border btn btn-dark" href="<?php echo SITEURL;?>mimages/<?php echo $userphoto;?>" download >

  <input name="<?php echo $popup;?>" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter"
value="Read More">
  
-->
<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ebc<?php echo $rows['id'] ?>"
>Read More</button>-->

<a class="btn btn-primary"  href="http://0.0.0.0:8080/Main_project/Service/ok.php?oweid=<?php echo $popup;?>&userid=<?php echo $id;?>" >Read More</a>



<!-- button click pop up start here -->
<div class="modal fade" id="ebc<?php echo $rows['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true"> 
<div class="modal-dialog modal-dialog-centered" role="document"> 
<div class="modal-content">

 <div class="modal-header"> 
<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button> 

</div>


 <div class="modal-body"> 


<div class="col-md-12  ">
<div class=" card ">

<div class="card-body"> 
<!--
$shop_name=$rows['shop_name'];
$main_ser=$rows['main_ser'];$sub_ser=$rows['sub_ser'];
$city=$rows['city'];
$address=$rows['address'];
$email=$rows['email'];
$contact=$rows['contact'];
$shop_lic=$rows['shop_lic'];-->

<h4 class="card-title"><?php echo $shop_name ?></h4>

</br>
Mob :+91<?php echo $contact ;?></p>
 
<address>
<?php echo $address."  ".$city;?>

</address>
<h4 class="fw-bold text-danger"><?php echo $main_ser ;?></h4>
<p class=" lead">
<?php echo $sub_ser ;?>

</p>

 <a href="<?php echo SITEURL;?>ownership_certificate/<?php echo $shop_lic;?>" class=" border btn btn-dark" download>Shop Licence</a>

  <div class="mt-3 form-group">  <textarea placeholder="Enter Requirement Here " class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea> </div>


</div>
</div>

</div>







</div> <div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>


  
<button onclick="closef()" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter1" data-dismiss="modal">Book</button>

<script>
 function closef()
{
document.getElementById("exampleModalCenter").style.display = "none";

}





</script>

</div> </div> </div> </div>
<!-- button click pop up -->

  
</form>
  </div>
  </div>
  
  </div>

<?php






}
}



//end of main if 
}



else
{
?>

<div class="main-service">
<div class="container">
<div class="row">





<?php
$sql="SELECT * FROM owener";


//$sql="SELECT * FROM  owener ";
$res=mysqli_query($conn,$sql) ;


$count=mysqli_num_rows($res) ;


if($count>0)
{

while($rows=mysqli_fetch_assoc($res))
{
$popup=$rows['id'];

$shop_name=$rows['shop_name'];
$main_ser=$rows['main_ser'];$sub_ser=$rows['sub_ser'];
$city=$rows['city'];
$address=$rows['address'];
$email=$rows['email'];
$contact=$rows['contact'];
$shop_lic=$rows['shop_lic'];



?>
<div class="col-md-6 mt-3 ">
  <div class=" card ">
  
  <div class="card-body"> 
  
  <h4 class="fw-bold text-danger card-title"><?php echo $shop_name ;?></h4>
  <p class=" lead ">
  
  Mob :+91 <?php echo $contact?></p>
   
  <address>
  <?php echo $address." ". $city?>
  </address>


  <h4 class="fw-bold text-danger">Service</h4>
  <p class=" lead">
  <?php echo $sub_ser;?>
  
  </p>
  
 <a href="<?php echo SITEURL;?>ownership_certificate/<?php echo $shop_lic;?>" class=" border btn btn-dark" download>Shop Licence</a>

 
 <!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#enc<?php echo $rows['id'] ?>"
>Read More</button>-->

<a class="btn btn-primary"  href="http://0.0.0.0:8080/Main_project/Service/ok.php?oweid=<?php echo $popup ?>&userid=<?php echo $id ?>">Read More </a>
  
  <!--  placing model here -->

 <div class="modal fade" id="ebnc<?php echo $rows['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true"> 
<div class="modal-dialog modal-dialog-centered" role="document"> 
<div class="modal-content">

 <div class="modal-header"> 
<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button> 

</div>




 <div class="modal-body"> 



<div class="col-md-12  ">
<div class=" card ">

<div class="card-body"> 


<h4 class="card-title"><?php echo $shop_name ?></h4>

</br>
Mob :+91<?php echo $contact ;?></p>
 
<address>
<?php echo $address."  ".$city;?>

</address>
<h4 class="fw-bold text-danger"><?php echo $main_ser ;?></h4>
<p class=" lead">
<?php echo $sub_ser ;?>

</p>

 <a href="<?php echo SITEURL;?>ownership_certificate/<?php echo $shop_lic;?>" class=" border btn btn-dark" download>Shop Licence</a>



<form method="POST">


  <div class="mt-3 form-group">  <textarea name="requirment" placeholder="Enter Requirement Here " class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea> </div>


  <div class="mt-3 form-group">  <input type="text" name="req"> </div>


</div>
</div>

</div>

</div> <div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>


  
<!-- <input name="book" type="submit" class="btn btn-primary" data-toggle="modal" data-target="#enc<?php echo $rows['id'];?>" data-dismiss="modal" value="Book">
-->

<a class="btn btn-primary" data-toggle="modal" href="http://0.0.0.0:8080/Main_project/Service/ok.php?id=<?php echo $popup ?>" >ok</a>



</form>

</div> </div> </div> </div>

<!-- placing finish here -->
  </div>
  </div>
 </div>


<!-- placing model 2 here 
<div class="modal fade" id="enc<?php echo $rows['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle1" aria-hidden="true"> <div class="modal-dialog modal-dialog-centered" role="document"> <div class="modal-content"> 


 <div class="modal-body">
<?php echo "oweners id".$rows['id'] ?>
<?php echo "user id".$userid?>







<div  style="display:none" id="success">
  <div  class="card">
      <div style="border:solid green; border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;">

<i  class="fa-solid fa-check"></i>
     
      </div>
        <h3 class="m-3 fw-bold" >Order success</h3> 
       
<p class="text-success">Your order was placed !  </p>
  
      </div>
</div>



<div  id="error">
  <div class="card">
      <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;">

<i  class="text-danger
fa-solid fa-triangle-exclamation">
</i>
     

          
        
         
      </div>
        <h1>Something went wrong </h1> 
        <p class="text-secondary">An unexpected error has occurred <br/> Please try again later !</p>
      </div>
</div>



</div> <div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>  </div> </div> </div> </div>


<!-- End of model 2 here-->




<?php



}


}
}
?>













</div>
</div>
</div>



 

 


</body>
</html>

