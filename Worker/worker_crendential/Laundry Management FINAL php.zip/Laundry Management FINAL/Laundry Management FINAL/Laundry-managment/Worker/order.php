<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
     #title{
     color: #e67e22;
    }
</style>

</head>
<body>
  <nav class="navbar  navbar-light ">
    <div class="container-fluid">
      <h1 id="title" class="navbar-brand fs-2 lead fw-bold">Cleanit</h1>
     
      <div class="justify-content-end offset-8  p-1" id="navbarSupportedContent">
        <form class="d-flex">
          <a href="../myindex.php" class=" order m-3 text-danger fw-bold">Home</a>
         
          <a href="Main_page.php" class=" order mt-3 text-danger fw-bold">Dashboard</a>
          <div class="p-3  mb-2">

<a href="notification.php"><i class="fa-solid fa-bell  text-danger"><span class="text-success">1</span></i>
</a>
        </div>

        <a href="profile.php">
          <img class="rounded-circle " height="50px" width="50px"
          src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" data-holder-rendered="true">
    
        </a>

        </form>
     
     
      </div>
    </div>
  </nav>
    <!-- <nav class="navbar  navbar-light ">
      <div class="container-fluid">
        <h1 id="title" class="navbar-brand fs-2 lead fw-bold">Cleanit</h1>
       
 
      </div>
    </nav> -->
    <div class="text-center">
        <h1  class="navbar-brand fs-2 lead text-secondary fw-bold">Manage order's</h1>
    </div>

<div class="container-fluid">
<div class="row">


  <div class=" p-3 col-lg-4 col-sm-6">
        <!-- Card -->
        <div class="card">
        <div class="comment ms-4 mt-4 text-justify float-left">
        <img  src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" alt="" class="rounded-circle" width="40" height="40">
        <p class="fw-bold lead">Jhon Doe</p>
        <span>+91 9579735564</span>
        <br>
        <p class="text-secondary lead">
        Deogiri Institute of Engineering and Management Studies,Aurangabad
        </p> 
        <div class="bg-white">
        <ol class="list-group list-group-numbered">
            <li class="list-group-item d-flex justify-content-between align-items-start">
                  <div class="ms-2 me-auto">
                    <div class="fw-bold text-info">Subheading</div>
                 
                  </div>
              
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-start">
                    <div class="ms-2 me-auto">
                        <div class="fw-bold text-info">Subheading</div>
                   
                    </div>
                
                  </li>
                  <li class="list-group-item d-flex justify-content-between align-items-start">
                    <div class="ms-2 me-auto">
                        <div class="fw-bold text-info">Subheading</div>
                   
                    </div>
                
                  </li>
              </ol>
              <div class="m-1">
                <span class="fw-bold lrad text-dark">Booking Time :</span><p class="text-danger fw-bold lead">12:00 AM</p>
                <span class="fw-bold lrad text-dark">Status : </span> <span class="fw-bold lrad text-danger"> Accepted</span>
              </div>
        </div>
        </div>
     

            <!-- Card content -->
            <div class="card-body">
                <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                    <option selected>Manage Order</option>
                    <option value="1">Completed</option>
                
                  </select>
                  
            </div>
          
          </div>
        
          <!-- Card -->
            </div>



            <div class=" p-3 col-lg-4 col-sm-6">
                <!-- Card -->
                <div class="card">
                <div class="comment ms-4 mt-4 text-justify float-left">
                <img  src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" alt="" class="rounded-circle" width="40" height="40">
                <p class="fw-bold lead">Jhon Doe</p>
                <span>+91 9579735564</span>
                <br>
                <p class="text-secondary lead">
                Deogiri Institute of Engineering and Management Studies,Aurangabad
                </p> 
                <div class="bg-white">
                <ol class="list-group list-group-numbered">
                    <li class="list-group-item d-flex justify-content-between align-items-start">
                          <div class="ms-2 me-auto">
                            <div class="fw-bold text-info">Subheading</div>
                         
                          </div>
                      
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-start">
                            <div class="ms-2 me-auto">
                                <div class="fw-bold text-info">Subheading</div>
                           
                            </div>
                        
                          </li>
                          <li class="list-group-item d-flex justify-content-between align-items-start">
                            <div class="ms-2 me-auto">
                                <div class="fw-bold text-info">Subheading</div>
                           
                            </div>
                        
                          </li>
                      </ol>
                      <div class="m-1">
                        <span class="fw-bold lrad text-dark">Booking Time :</span><p class="text-danger fw-bold lead">12:00 AM</p>
                        <span class="fw-bold lrad text-dark">Status : </span> <span class="fw-bold lrad text-danger"> Accepted</span>
                      </div>
                </div>
                </div>
             
        
                    <!-- Card content -->
                    <div class="card-body">
                        <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                            <option selected>Manage Order</option>
                            <option value="1">Completed</option>
                        
                          </select>
                          
                    </div>
                  
                  </div>
                
                  <!-- Card -->
                    </div>

        
                    <div class=" p-3 col-lg-4 col-sm-6">
                        <!-- Card -->
                        <div class="card">
                        <div class="comment ms-4 mt-4 text-justify float-left">
                        <img  src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" alt="" class="rounded-circle" width="40" height="40">
                        <p class="fw-bold lead">Jhon Doe</p>
                        <span>+91 9579735564</span>
                        <br>
                        <p class="text-secondary lead">
                        Deogiri Institute of Engineering and Management Studies,Aurangabad
                        </p> 
                        <div class="bg-white">
                        <ol class="list-group list-group-numbered">
                            <li class="list-group-item d-flex justify-content-between align-items-start">
                                  <div class="ms-2 me-auto">
                                    <div class="fw-bold text-info">Subheading</div>
                                 
                                  </div>
                              
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-start">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold text-info">Subheading</div>
                                   
                                    </div>
                                
                                  </li>
                                  <li class="list-group-item d-flex justify-content-between align-items-start">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold text-info">Subheading</div>
                                   
                                    </div>
                                
                                  </li>
                              </ol>
                              <div class="m-1">
                                <span class="fw-bold lrad text-dark">Booking Time :</span><p class="text-danger fw-bold lead">12:00 AM</p>
                                <span class="fw-bold lrad text-dark">Status : </span> <span class="fw-bold lrad text-danger"> Accepted</span>
                              </div>
                        </div>
                        </div>
                     
                
                            <!-- Card content -->
                            <div class="card-body">
                                <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                                    <option selected>Manage Order</option>
                                    <option value="1">Completed</option>
                                
                                  </select>
                                  
                            </div>
                          
                          </div>
                        
                          <!-- Card -->
                            </div>

    </div>
    </div>




</body>
</html>