<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="index.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>
  </head>
<body>

    <nav class="navbar  navbar-light ">
      <div class="container-fluid">
        <h1 id="title" class="navbar-brand fs-2 lead fw-bold">Cleanit</h1><br/>
      

        <div class="justify-content-end offset-8  p-1" id="navbarSupportedContent">
          <form class="d-flex">
           
       <p class="fw-bold">welcome rutik jalhare</p>
        
         </form>
      
        </div>
      </div>
    </nav>


<div class="container-fluid">
<div class="row">

<div class=" p-3 col-lg-4 col-sm-6">
        <!-- Card -->
        <div class="card">
        <div class="comment ms-4 mt-4 text-justify float-left">
        <img  src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" alt="" class="rounded-circle" width="40" height="40">
        <p class="fw-bold lead">Jhon Doe</p>
        <span>+91 9579735564</span>
        <br>
        <p class="text-secondary lead">
        Deogiri Institute of Engineering and Management Studies,Aurangabad
        </p> 
        <div class="bg-white">
        <ol class="list-group list-group-numbered">
            <li class="list-group-item d-flex justify-content-between align-items-start">
                  <div class="ms-2 me-auto">
                    <div class="fw-bold text-info">Dry Cleaning</div>
                 
                  </div>
              
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-start">
                    <div class="ms-2 me-auto">
                        <div class="fw-bold text-info">Sream Ironing </div>
                   
                    </div>
                
                  </li>
                  <li class="list-group-item d-flex justify-content-between align-items-start">
                    <div class="ms-2 me-auto">
                        <div class="fw-bold text-info">Laundry</div>
                   
                    </div>
                
                  </li>
              </ol>
             
        </div>
        </div>
            <!-- Card content -->
            <div class="card-body">
   
                  <button type="button" class="btn btn-info " data-toggle="modal" data-target="#myModal">View </button>
              
           </div>
         
           <div class="card-body">
            <button type="button" class="opacity-75 btn btn-primary">Approve</button>   
            <button type="button" class="btn btn-danger">Reject</button> 
            <p class="fs-3">status : <span class="text-success">Accepted</span></p>         
             </div>     


          </div>
        
          <!-- Card -->
 </div>

        

 <div class=" p-3 col-lg-4 col-sm-6">
      <!-- Card -->
      <div class="card">
      <div class="comment ms-4 mt-4 text-justify float-left">
      <img  src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" alt="" class="rounded-circle" width="40" height="40">
      <p class="fw-bold lead">Jhon Doe</p>
      <span>+91 9579735564</span>
      <br>
      <p class="text-secondary lead">
      Deogiri Institute of Engineering and Management Studies,Aurangabad
      </p> 
      <div class="bg-white">
      <ol class="list-group list-group-numbered">
          <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold text-info">Dry Cleaning</div>
               
                </div>
            
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-start">
                  <div class="ms-2 me-auto">
                      <div class="fw-bold text-info">Sream Ironing </div>
                 
                  </div>
              
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-start">
                  <div class="ms-2 me-auto">
                      <div class="fw-bold text-info">Laundry</div>
                 
                  </div>
              
                </li>
            </ol>
           
      </div>
      </div>
          <!-- Card content -->
          <div class="card-body">
      
            <button type="button" class="btn btn-info " data-toggle="modal" data-target="#myModal">View </button>
              
         </div>
       
         <div class="card-body">
          <button type="button" class="opacity-75 btn btn-primary">Approve</button>   
          <button type="button" class="btn btn-danger">Reject</button>  
          <p class="fs-3">status : <span class="text-success">Accepted</span></p>         
                  
           </div>     


        </div>
      
        <!-- Card -->
</div>




<div class=" p-3 col-lg-4 col-sm-6">
      <!-- Card -->
      <div class="card">
      <div class="comment ms-4 mt-4 text-justify float-left">
      <img  src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" alt="" class="rounded-circle" width="40" height="40">
      <p class="fw-bold lead">Jhon Doe</p>
      <span>+91 9579735564</span>
      <br>
      <p class="text-secondary lead">
      Deogiri Institute of Engineering and Management Studies,Aurangabad
      </p> 
      <div class="bg-white">
      <ol class="list-group list-group-numbered">
          <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold text-info">Dry Cleaning</div>
               
                </div>
            
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-start">
                  <div class="ms-2 me-auto">
                      <div class="fw-bold text-info">Sream Ironing </div>
                 
                  </div>
              
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-start">
                  <div class="ms-2 me-auto">
                      <div class="fw-bold text-info">Laundry</div>
                 
                  </div>
              
                </li>
            </ol>
           
      </div>
      </div>
          <!-- Card content -->
          <div class="card-body">

        <button type="button" class="btn btn-info " data-toggle="modal" data-target="#myModal">View </button>
       
         </div>
       
         <div class="card-body">
          <button type="button" class="opacity-75 btn btn-primary">Approve</button>   
          <button type="button" class="btn btn-danger">Reject</button> 
          <p class="fs-3">status : <span class="text-success">Accepted</span></p>         
                   
           </div>     


        </div>
      
        <!-- Card -->
</div>

            

    </div>
    </div>




 <!-- Modal -->
 <div class="modal fade" id="myModal" role="dialog">
      <div class="modal-dialog">
      
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
           <h4 class="modal-title">Modal Header</h4>
          </div>
          <div class="modal-body">
              <embed src="javascript.pdf"
              frameborder="0" width="100%" height="400px">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
        
      </div>
    </div>












</body>
</html>