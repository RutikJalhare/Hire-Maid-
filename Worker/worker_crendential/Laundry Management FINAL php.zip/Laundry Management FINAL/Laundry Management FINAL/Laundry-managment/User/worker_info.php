<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://kit.fontawesome.com/70ebe3073f.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="index1.css">
   
  </head>
<body>
      <div class="container mt-5">
    
            <div class="row d-flex justify-content-center">
                
                <div class="col-md-7">
                    
                    <div class="card p-3 py-4">
                        
                        <div class="text-center">
                            <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" width="100" class="rounded-circle">
                        </div>
                        
                        <div class="text-center mt-3">

                            <h5 class="mt-2 mb-0">Jhon Doe</h5>
                            <span>+91 9579735564</span>
                            
                            <div class="px-4 mt-1">
                                <p class="fonts">
                                    Deogiri Institute of Engineering and Management Studies,Aurangabad   </p>
                            
                            </div>
                   
                            
                          


                          <p class="text-start ms-3 fw-bold">Select Services </p> 

                          <div class="rating ">
                                  <div  class="btn-group btn-group-toggle" data-toggle="buttons">
                                 <label class="btn btn-success opacity-50 m-2">
                                 <input type="checkbox" > Dry Cleaning 
                                    </label>
                                   </div>    
                              </div>
                        
                              <div class="rating ">
                                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                   <label class="btn btn-success opacity-50 m-2">
                                   <input type="checkbox" > Steam Ironing
                                      </label>
                                     </div>    
                                </div>
                                <div class="rating ">
                                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                   <label class="btn btn-success opacity-50 m-2">
                                   <input type="checkbox" > Laundry 
                                      </label>
                                     </div>    
                                </div>
                               
                                              


<!-- comment section start  -->
<div class="container mt-3">
    
          <div class="col-md-12">
                  <div class="bg-white p-2">
                      <div class="d-flex flex-row user-info">
                        <img class="rounded-circle" src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" width="45">
                          <div class="d-flex flex-column justify-content-start ml-2"><span class="d-block font-weight-bold name">Marry Andrews</span><span class="date text-black-50">Shared publicly - Jan 2020</span></div>
                      </div>
                      <div class="mt-2 text-dark lead  text-justify">
                          <p class="comment-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                      </div>
                  </div>
         
           </div>




           <div class="col-md-12">
            <div class="bg-white p-2">
                <div class="d-flex flex-row user-info">
                  <img class="rounded-circle" src="https://mdbootstrap.com/img/Photos/Avatars/img%20(30).jpg" width="45">
                    <div class="d-flex flex-column justify-content-start ml-2"><span class="d-block font-weight-bold name">Marry Andrews</span><span class="date text-black-50">Shared publicly - Jan 2020</span></div>
                </div>
                <div class="mt-2 text-dark lead  text-justify">
                    <p class="comment-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                </div>
            </div>
   
     </div>

</div>  
<!-- comment section end   -->





                            <div class="buttons">
                                
                                <button class="btn btn-outline-primary px-4">view More </button>
                                <button class="btn btn-outline-primary px-4">Hire</button>
                           
                              </div>
                            
                            
                        </div>
                        
                       
                        
                        
                    </div>
                    
                </div>
                
            </div>
            
        </div>
  







</body>
</html>